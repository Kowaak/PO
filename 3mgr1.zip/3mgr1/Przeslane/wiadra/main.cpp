#include <iostream>

using namespace std;

int main()
{
    int w1[5],w2[7],w3[12];
    int ile;
    for()

    cout<<"Podaj ile wody chcesz wyznaczyc: ";
    cin>>ile;
    return 0;
}
