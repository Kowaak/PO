#include <iostream>
using namespace std;

class Print{
private:
    int number,numer;
public:
    Print(int pnum,int pnum2){
        number = pnum;
        numer = pnum2;
    }
    void operator + (){
        number += 5;
    }
    void operator - (){
        number -= 5;
    }
    void operator * (){
        number *= 5;
    }
    void operator / (double i){
        number /= 5;
    }
    void display(){
        cout<<"Wynik: "<<number<<endl;
    }

};
int main() {
   Print p1(5,4);
   p1.display();
   +p1;
   p1.display();
   -p1;
   p1.display();
   *p1;
   p1.display();
   p1.operator/(4);
   p1.display();


}
