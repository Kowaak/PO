#include <iostream>
using namespace std;
void menu();
float mnoz(float a, float b);
float dziel(float a, float b);
float dod(float a, float b);
float odej(float a, float b);
float klej(float a, float b);
int ab(int n);
int signumn(int m);
int main(void){
    int a;
    float b,c;

    menu();

    cin>>a;
    cout<<"Podaj dane: ";
    cin>>b>>c;
    switch(a)
        {
           case1: cout<<mnoz(b,c);break;
             case2: cout<<dziel(b,c);break;
             case3: cout<<dod(b,c);break;
             case4: cout<<odej(b,c);break;
            case5: return 0;
            case6: cout<<klej(b,c);break;

            default:cout<<"Zla dana: ";
        }
        return 0;
    }
    void menu()
    {

        cout<<"\t\tMenu\n\n";
        cout<<"1 - mnozenie\n";
        cout<<"2 - dzielenie\n";
        cout<<"3 - dodawanie\n";
        cout<<"4 - odejmowanie\n";
        cout<<"5 - koniec\n";
        cout<<"6 - klej\n";
    }
    float mnoz(float a, float b)
    {
        return (a*b);

    }
     float dziel(float a, float b)
    {
        return (a/b);

    }
     float dod(float a, float b)
    {
        return (a+b);

    }
     float odej(float a, float b)
    {
        return (a-b);

    }
    float klej(float a,float b)
    {

    return(a+b*a);
    }
    int ab(int n)
    {

        return(n<0 ? -n: n);
    }
