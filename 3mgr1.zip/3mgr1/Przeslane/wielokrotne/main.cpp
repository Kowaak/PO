#include <iostream>

using namespace std;
class info{
protected:
    int clo;
    string fab;
};
class Tshirt:public info{
public:
    Tshirt(int pclo,string pfab){
        clo = pclo;
        fab = pfab;
        cout<<"Wyprodukowano "<<clo<<" sztuk koszulek z "<<fab<<endl;
    }
};
class Spodnie:public info{
public:
    Spodnie(int pclo,string pfab){
        clo = pclo;
        fab = pfab;
        cout<<"Wyprodukowano "<<clo<<" sztuk spodni z "<<fab<<endl;
    }
};

int main() {
    Tshirt t1(15,"Bawelna");
    Spodnie s1(10,"Poliester");
}
