#include <iostream>
#include <cstdio>
#include <cmath>

    using namespace std;

int main()
{
    cout<<"Ceil"<<endl;
    cout<<ceil(4.00)<<endl;
    cout<<ceil(3.49)<<endl;
    cout<<ceil(3.50)<<endl;
    cout<<ceil(-3.49)<<endl;
    cout<<ceil(-3.50)<<endl;
    cout<<ceil(-4.00)<<endl;

 /*   cout<<"Floor"<<endl;
    cout<<floor(4.00)<<endl;
    cout<<floor(3.49)<<endl;
    cout<<floor(3.50)<<endl;
    cout<<floor(-3.49)<<endl;
    cout<<floor(-3.50)<<endl;
    cout<<floor(-4.00)<<endl;

    cout<<"Round"<<endl;
    cout<<round(4.00)<<endl;
    cout<<round(3.49)<<endl;
    cout<<round(3.50)<<endl;
    cout<<round(-3.49)<<endl;
    cout<<round(-3.50)<<endl;
    cout<<round(-4.00)<<endl;

    cout<<"fmod"<<endl;
    cout<<fmod(4.00,1)<<endl;
    cout<<fmod(3.49,1)<<endl;
    cout<<fmod(3.50,1)<<endl;
    cout<<fmod(-3.49,1)<<endl;
    cout<<fmod(-3.50,1)<<endl;
    cout<<fmod(-4.00,1)<<endl;

   /* cout<<"abs"<<endl;
    cout<<abs(4.00)<<endl;
    cout<<abs(3.49)<<endl;
    cout<<abs(3.50)<<endl;
    cout<<abs(-3.49)<<endl;
    cout<<abs(-3.50)<<endl;
    cout<<abs(-4.00)<<endl; */

    cout<<"pow"<<endl;
    cout<<pow(4.00,2)<<endl;
    cout<<pow(3.00,2)<<endl;
    cout<<pow(-4.00,2)<<endl;

    cout<<"sqrt"<<endl;
    cout<<sqrt(4)<<endl;
    cout<<sqrt(3)<<endl;
    cout<<sqrt(-4.00)<<endl;
    return 0;
}
