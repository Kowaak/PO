#include <iostream>

using namespace std;

class Print;

class SetNum{
private:
    int number;
public:
    SetNum(int pnum){
        number = pnum;
    }
    friend class Print;
};
class Print{
public:
    void display(SetNum &obiekt){
        cout<<"Wartosc atrybutu number: "<<obiekt.number<<endl;
    }
};
int main()
{
    SetNum set_1(7);
    Print print_1;
    print_1.display(set_1);
    return 0;
}
/*
class SetNum;

class Print{
public:
    void display(SetNum&);
};

class SetNum{
private:
    string number;
public:
    SetNum(string pnum){
        number = pnum;
    }
    friend void Print::display(SetNum &obiekt);
};
void Print::display(SetNum &obiekt){
    cout<<"Wartosc atrybutu: "<<obiekt.number<<endl;
}
int main()
{
    SetNum set_1("Adam");
    Print print_1;
    print_1.display(set_1);
    return 0;
}*/
