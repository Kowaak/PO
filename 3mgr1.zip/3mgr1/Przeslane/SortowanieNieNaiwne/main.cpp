#include <iostream>
#include <math.h>
#include <string>
using namespace std;

int main()
{
    string wz = "BAAB";
    string sl = "BBAABBAAB";
    wzl = wz.lenght();
    sll = sl.lenght();


    return 0;
}
