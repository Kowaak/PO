#include <iostream>

using namespace std;
class Fibo{
public:
    int fib(int n){
        int wyn;

        cout<<"Wartosc "<<n<<". elementu ciagu Fibonacciego: "<< <<endl;
    }
};
int main()
{
    Fibo f1,f2;
    f1.fib(6);
    f2.fib(7);
    return 0;
}
