#include <cstdlib>
#include <iostream>

using namespace std;

int dodawanie ( int a, int b){
    int wynik = a + b;
    return wynik;
}

int main(int argc, char *argv[])
{
    int a;
    a = dodawanie(6,8);
    cout<<a;

    system("PAUSE");
    return EXIT_SUCCESS;
}
void funkcja (){
    int a = 7;
}

// wewn�trz main
funkcja();
a=8;

// przed main
void funkcja( int a){
    a = a + 1;
}

// wewn�trz main
int a = 7;
funkcja(a);
cout<<a;
int funkcja( int a){
    a = a + 1;
    return a;
}

int main(int argc, char *argv[])
{
    int a = 7;
    a = funkcja(a);
    cout<<a;
}
