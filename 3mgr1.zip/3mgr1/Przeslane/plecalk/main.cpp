#include <iostream>

using namespace std;

int main()
{
    int plecak = 11;
    cout << "" << endl;
    int a1=8,a2=4,b1=3,b2=2,c1=1,c2=1,d1=2,d2=3,e1=1,e2=7;

    cout<<"Strategia nr.1"<<endl;


    return 0;
}
