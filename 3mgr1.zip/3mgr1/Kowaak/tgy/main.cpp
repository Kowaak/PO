/*include<iostream>
using namespace std;

union liczba{
        int calkowita;
        long long dluga;
        double rzeczywista;
};

int main()
{
    liczba a, b, c, d;
    cout<<"Unia zajmuje "<<sizeof(liczba)<<" bajt�w"<<endl;

    cout<<"Podaj trzy liczby ca�kowite: ";

    cin>>a.calkowita>>b.calkowita>>c.calkowita;

    d.rzeczywista = double(a.calkowita+b.calkowita+c.calkowita)/3.0;

    cout<<"�rednia wczytanych liczb wynosi: "<<d.rzeczywista<<endl;
    cin>>a.dluga>>a.rzeczywista>>a.calkowita;
    cout<<a.dluga<<a.rzeczywista<<a.calkowita<<endl;
    return 0;
}*/
#include<iostream>
using namespace std;

union plec{
    char MK;
    //string plec;
};

struct uczen{
	char imie[20];
	char nazwisko[20];
	int nr;
	plec ucz;
};

int main()
{
	uczen uczen1;

	cout<<"Podaj imie: ";
	cin>>uczen1.imie;
	cout<<"Podaj nazwisko: ";
	cin>>uczen1.nazwisko;
    cout<<"Podaj nr: ";
	cin>>uczen1.nr;
    cout<<"Podaj plec: ";
	cin>>uczen1.ucz.MK;


	cout<<"Imie: "<<uczen1.imie<<endl;
	cout<<"Nazwisko: "<<uczen1.nazwisko<<endl;
	cout<<"Nr: "<<uczen1.nr<<endl;
	cout<<"Plec: "<<uczen1.ucz.MK<<endl;

	return 0;
}
