#include <iostream>

using namespace std;

int naj(int a ,int b, int c){
    return a>b?(a>c?a:c):(b>c?b:c);
}
int main()
{
    cout<<naj(3,7,99);
    return 0;
}
