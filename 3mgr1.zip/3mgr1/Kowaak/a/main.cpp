#include <iostream>
#include <ctime>
using namespace std;

int main()
{
    system("color 0a");
    int x = 1;
    int tab[4][3];
    for(int i=0;i<4;i++){
        for(int j=0;j<3;j++){
        tab[i][j]=x;
        cout<<tab[i][j]<<" ";
        x+=2;
        }
        x-=1;
        cout<<endl;
    }
    cout<<"Zad 2"<<endl;
    double tab2[5][5];
    srand(time(NULL));
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
        double y = -20 + (double) rand()/RAND_MAX*108;
        tab2[i][j] = y;
        cout<<tab2[i][j]<<" | ";
        }
        cout<<endl;
    }
    cout<<"Zad 3"<<endl;
    double tab3[5][5];
    double suma;
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
        double y = -10 + (double) rand()/RAND_MAX*20;
        tab3[i][j] = y;
        if(tab3[i][j]<0){
            tab3[i][j] = tab3[i][j]-2;
        }
        cout<<tab3[i][j]<<" | ";
        suma += tab3[i][j];
        }
        cout<<"Suma: "<<suma;
        suma = 0;
        cout<<endl;
    }
    cout<<"Zad 4"<<endl;
    double tab4[5][5];
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
        double y = 1 + (double) rand()/RAND_MAX*51;
        tab4[i][j] = y;
        cout<<tab4[i][j]<<" | ";

        }
        cout<<endl;
    }
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
    if(tab4[i][j]>10){
            cout<<"Na pozycji: "<<i<<" "<<j<<endl;
        }
        }
    }
    cout<<"Zad 5"<<endl;
    double tab5[5][5];
    int iloczyn;
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
        double y = 1 + (double)rand()/RAND_MAX*51;
        tab5[i][j] = y;
        cout<<tab5[i][j]<<" | ";
        }
        cout<<endl;
  /*  }
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
        if(tab5[i][j] !=0){
            iloczyn++;
        }
        }*/
    }
    //cout<<iloczyn<<endl;
    return 0;
}
