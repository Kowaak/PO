#include <iostream>

using namespace std;

int main()
{
    int n=4;

    int tab[5] = {1,3,1,3,7};
    int x=2;
    int i=0;
    int w=tab[0];
    while(i<n)
    {
        w=w*x+tab[i+1];
        i=i+1;
    }
    cout<<w;


    return 0;
}
