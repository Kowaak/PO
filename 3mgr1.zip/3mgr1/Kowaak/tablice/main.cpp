#include <iostream>

    float tab[10];
    float s;

using namespace std;
void wczytaj() {
    for(int i = 0;i<10;i++){
        cin>>tab[i];
    }
}
void wypisz(){
    for(int i = 0;i<10;i++){
        s=s+tab[i];
    }
    cout<<"Suma wynosi: "<<s;
}
int main()
{
    wczytaj();
    wypisz();
    //wpisz do tablicy znakowej swoje imie i je wyswietl
    //zastosuj tablice liczb rzeczywistych, wpisz dane i wyswietl sume
    //napisz program wykorzystujacy funckje do wczytania tablicy
    return 0;
}
