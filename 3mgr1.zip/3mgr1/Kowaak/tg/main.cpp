#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    cout << tan(0)<< endl;
    cout << tan(M_PI/30)<< endl;
    cout << tan(M_PI/45)<< endl;
    cout << tan(M_PI/60)<< endl;
    //cout << tan(M_PI/2)<< endl;
    cout << tan(M_PI/180)<< endl;
    return 0;
}




//wymien praktyczne zastosowania tg
