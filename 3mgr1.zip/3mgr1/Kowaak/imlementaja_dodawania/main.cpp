#include <iostream>
#include <math.h>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
    int a=3,b=5;
    cout <<sqrt(7/pow(a,3)+cos(b))<< endl;
    cout <<sqrt(7/pow(a,3)+cos(b))<< endl;
    cout <<sqrt(7/pow(a,3)+cos(b))<< endl;
    //aby sko�ysta� z generatora liczb lososwych nalezy umiescic 2 bibioteki, ctime i cstdlib
    //funkcja rand generuje liczbe pseudolosowa ca�kowiata, od 0 do RAND_MAX
    //RAND_MAX = 32767
    //srand(time(NULL); to funkcja inicjuj�ca funkcje rand
    srand(time(NULL));
    int p=1,q=49;
    int liczba = p+rand()%(q-p+1);
    cout << "od p do q "<<liczba<<endl;
    liczba = p+(double)rand()/RAND_MAX*(q-p+1);
    cout << "od p do q "<<liczba<<endl;
    liczba = (double)rand()/RAND_MAX;
    cout << "od p do q "<<liczba<<endl;


    return 0;
}
