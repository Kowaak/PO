#include <iostream>

using namespace std;

int main()
{
    float x,pole,y;
    cout<<"Podaj koniec przedzialu: ";
    cin>>x;
    for(int i = 1;i<=x;i++){
     y=(i-0.5)*(i-0.5)+2;
     pole=pole+y;
    }
    cout<<"Wynik: "<<pole<<endl;
    pole=0;
    cout<<"(nadmiar): ";
    for(int i = 1;i<=x;i++){
     y=(i-0)*(i-0)+2;
     pole=pole+y;
    }
    cout<<"Wynik: "<<pole<<endl;
    pole=0;
    cout<<"(niedomiar): ";
    for(int i = 1;i<=x;i++){
     y=(i-1)*(i-1)+2;
     pole=pole+y;
    }
    cout<<"Wynik: "<<pole<<endl;
    pole=0;
    return 0;
}
