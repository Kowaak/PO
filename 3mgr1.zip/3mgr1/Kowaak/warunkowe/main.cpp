#include <iostream>

using namespace std;

int main()
{
    int i = 1,j = 2;
    cout << ( i > j ? i : j )<<" jest wieksze."<<endl;
    int a=3,b=2;
    (a<b) ? cout<<"a jest mniejsze":cout<<"b jest mniejsze"<<endl;
    if(a<b)
        cout<<"a jest mniejsze"<<endl;
    else
        cout<<"b jest mniejsze "<<endl;
    int mni = (a<b)?a:b;
    cout<<"Mniejsza warto�� wynosi "<<mni<<endl;




    return 0;
}
