#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    float p,k,wynik,w,x,pole;
    cout<<"Podaj poczatek przedzialu (wiekszy lub rowny 1)"<<endl;
    cin>>p;
    cout<<"Podaj koniec przedzialu (wiekszy od poczatku)"<<endl;
    cin>>k;
    for(;p<=k;p++){
        x = pow(2 * p,2) + 3;
        pole = 0.5*(x + x);
    }
    cout<<
    return 0;
}
