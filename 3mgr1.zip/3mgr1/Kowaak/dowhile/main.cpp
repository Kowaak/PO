#include <iostream>

using namespace std;

int main()
{
   /* petla do while nie ma okreslonej ilosci obrotow ale wiemy ze wykona sie przynajmniej raz.
    najpierw wykonywane sa instrukcje a dopiero potem sprawdzany warunek.
    do{
        cout
    } while();
    */
    //zadanie
    //zsumuj cyfry podawane przez uzytkonika tak dlugo az ich suma bedzie wieksza od 1000
    int a,b;
    do{
        cout<<"Podaj liczb�: ";
        cin>>a;
        b=b+a;
        cout<<b<<endl;
    }while(b<=1000);
    int i=0,poz=1;
    cout<<"Ile razy powtorzyc petle?"<<endl;
    cin>>i;
    for(;i>0;i--){
        cout<<poz<<"Napis"<<endl;
        poz++;
    };
    return 0;
}
