#include <iostream>

using namespace std;

int obliczSume(int a){
    return a;
};
int obliczSume(int a, int b){
    return a+b;
};
int obliczSume(int a, int b, int c){
    return a+b+c;
};
void wypisz(int a){
    cout<<a<<endl;
};
void wypisz(double a){
    cout<<a<<endl;
};
void wypisz(char a){
    cout<<a<<endl;
};
int oblicz(int d,int e,int f)
int main()
{
    int d,e,f;
    cout<<obliczSume(5)<< endl;
    cout<<obliczSume(5,7)<< endl;
    cout<<obliczSume(5,9,12)<<endl;
    wypisz(7);
    wypisz(3.83);
    wypisz('p');

    return 0;
}







