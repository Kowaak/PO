#include <iostream>
#include <cmath>
using namespace std;
#define moja_stala 24

#define M_E        2.71828182845904523536
#define M_LOG2E    1.44269504088896340736
#define M_LOG10E   0.434294481903251827651
#define M_LN2      0.693147180559945309417
#define M_LN10     2.30258509299404568402
#define M_PI       3.14159265358979323846
#define M_PI_2     1.57079632679489661923
#define M_PI_4     0.785398163397448309616
#define M_1_PI     0.318309886183790671538
#define M_2_PI     0.636619772367581343076
#define M_2_SQRTPI 1.12837916709551257390
#define M_SQRT2    1.41421356237309504880
#define M_SQRT1_2  0.707106781186547524401

int main()
{
    system("color 0a");
    /*
    int a = 4,b = 6,k;
    cout<<a<<" "<<b<<endl;
    a += 1;
    cout<<a<<" "<<b<<endl;
    a -= 1;
    cout<<a<<" "<<b<<endl;
    a *= 1;
    cout<<a<<" "<<b<<endl;
    a /= 1;
    cout<<a<<" "<<b<<endl;
    a *= 4*b-1;
    a = a * (4*b-1);
    cout<<a<<" "<<b<<endl;
    a=1;
    b=2;
    k=1;
    k += (a*=2) = (b+=3); k = k + (a = a*2) - (b = b+3)
    int a,b,mi,ma;
    cout<<"Podaj a: ";
    cin>>a;
    cout<<"Podaj b: ";
    cin>>b;
    mi = a<b?a:b;
    ma = a<b?b:a;
    cout<<mi<<" "<<ma<<endl;
    wczytaj liczbe i sprawdz czy jest parzysta czy nie.
    cout<<"Podaj a: ";
    cin>>a;
    b = a % 2;
    if(a=0){
        cout<<"Liczba jest parzysta";
    }else{
        cout<<"Liczba jest nie parzysta";
    }
    Priorytety relacji i dzialan
     a = 7/3*2-7%9/2 = (7/3)*2 - (7%9)/2
    funkcje matematyczne
    ceil - zaokragla w gore
    floor - zaokragla w dol
    round - zaokrogla normalnie
    */
    cout<<pow(8,0.3)<<endl;
    cout<<M_E<<endl;
    cout<<M_PI<<endl;
    //definiowanie stalych
    cout<<moja_stala + 6<<endl;

    return 0;
};
