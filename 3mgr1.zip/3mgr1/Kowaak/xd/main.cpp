#include <iostream>
#include <cmath>

using namespace std;

//float w(float a){return (pow(cos(a/180*M_PI),2)+pow(sin(a/180*M_PI),2));}

int main()
{
    /*cout << w(0) << endl;
    cout << w(30) << endl;
    cout << w(45) << endl;
    cout << w(60) << endl;
    cout << w(90) << endl;
    cout << w(180) << endl;*/
    cout
    float sin = sqrt(1 - pow(cos, 2));

    cout<<"sin = "<<sin<<endl;
    cout<<"tg = "<<<<endl;
    cout<<"ctg = "<<<<endl;

    return 0;
}
//obicz sin alfa tg i ctg jesli cos = 1/3
