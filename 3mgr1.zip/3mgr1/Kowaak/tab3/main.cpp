#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
    int suma;
    int t[6][5];
    int tab[5];
    for(int i=0;i<6;i++){
        for(int j=0;j<5;j++){
            t[i][j]=i+j;
            tab[j] = t[i][j];
            if(i>j){
                cout<<t[i][j]<<"\t";
                suma=suma+t[i][j];
            }else{
                cout<<t[i][j]<<"\t";
            }
        }
        cout<<endl;
    }
    cout<<"Suma: "<<suma<<endl;
    for(int i=0;i<5;i++){
        cout<<tab[i]<<".";
    }
    return 0;
}
