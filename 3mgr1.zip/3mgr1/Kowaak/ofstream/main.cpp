#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ofstream zapis("dane4.txt");
    if(!zapis){
        cout<<"pliku nie znaleziono"<<endl;
        return 0;
    }

	for (int i =5;i<501;i++){
        zapis<<i<<"\n";
	}
	zapis.close();
    int gg;
	ifstream odczyt("dane4.txt");
	if(odczyt.is_open())
	{
		char wiersz[10000];
		while(odczyt.getline(wiersz,10000))
		{
			ofstream wynik("wynik.txt");
			for (int i = 5;i<501;i++){
                gg == wiersz;
                if(gg%7==0){
                    wynik<<gg<<" ";
                }
            }
			wynik.close();
		}
	}
	else
		cout<<"Nie udało się otworzyć pliku";

    odczyt.close();


		//napisz prgram zapisujacy do pliku wartosci od 5 do 500. Plik nazwij dane4.txt
		//otwórz plik do odczytui przepisz wszystkie liczby podzielne przez 7 do pliku wynik.txt
		//wyswietl wynik

    system("pause");
	return 0;
}
