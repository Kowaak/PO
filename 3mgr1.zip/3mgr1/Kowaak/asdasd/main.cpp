#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
    srand(time(NULL));
    float p = -10,q = 23,suma,iloczyn = 1;
    float tab[10];
    int tab2[15];
    for(int i=0;i<10;i++){
        tab[i]=p + (double)rand()/RAND_MAX*(q-p);
    }
    cout<<"Wylosowane liczby: "<<endl;
    for(int i=0;i<10;i++){
       cout<<tab[i]<<endl;
    }
    for(int i=0;i<10;i++){
       suma=suma+tab[i];
    }
    cout<<"Suma liczb: "<<suma<<endl;
    for(int i=0;i<10;i++){
       if(tab[i]<6)
            iloczyn = iloczyn * tab[i];
    }
    cout<<"Iloczyn liczb: "<<iloczyn<<endl;
    cout<<"====================== Zad 2 ======================"<<endl;
    for(int i=0;i<15;i++){
        tab2[i]=rand()%(10+1);
        cout<<tab2[i]<<endl;
    }
    cout<<"Najczestsze: "<<"SUS"<<endl;
    cout<<"Najrzadsze: "<<"Bing cziling"<<endl;
    return 0;
}


//wprowadzenie liczb rzeczywistych wygenerowanych z przedzialu od -10 do 23 do tablicy 10 ele.
//oblicz sume wszystkich elementow tablicy
//oblicz iloczyn tych element�w kt�re s� mniejsze od 6

//napisz prgram wypelniajacy 15 ele. tabele(int) liczbami losowymi z przedzilu od 0 do 10, wyswietl ktore
//wystepuja najczesciej a ktore najrzadziej
