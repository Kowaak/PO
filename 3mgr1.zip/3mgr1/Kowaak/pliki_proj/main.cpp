#include <iostream>
#include <fstream>

using namespace std;

int op;
string plik;

void utw(string plik){
    ofstream zapis(plik+".txt");
    zapis.close();
}
void usu(string plik){

}
void odcz(string plik){


}

int main()
{
    cout << "Menu - wybierz opcje" << endl;
    cout << "1 - Nowy plik" << endl;
    cout << "2 - Edycja" << endl;
    cout << "3 - Kasowanie" << endl;
    cout << "4 - Odczyt" << endl;
    cout << "5 - Koniec" << endl;
    cin>>op;
    switch(op){
        case 1:
            cout<<"Podaj nazwe nowego pliku: ";
            cin>>plik;
            utw(plik);
            cout<<"Plik zostal stworzony";
            break;
        case 2:

            break;
        case 3:

            break;
        case 4:

            break;
        case 5:
            return 0;
        default:
            cout<<"Blad"<<endl;
            return 0;
    }
    return 0;
}
