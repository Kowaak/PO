#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    //napisz prgram wyswietlajacy koljne potegi 2, uzytkownik wpisuje ile ich chce
    int a,b;
    cout << "Ile chcesz poteg: ";
    cin>>a;
    for(int i = 0;i<a;i++){
    b=pow(2,i);
    cout<<b<<" ";
    }
    //napisz prgram wyswitlajacy liczby podzilne przez 3 i 7 bez reszty z przdzialu od 1 do 100
    return 0;
}
