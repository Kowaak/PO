#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;


void wczytaj(float t[])
{
    srand(time(NULL));
    int i=0;
do
{
    t[i]=-10 +(double)rand() / RAND_MAX * (10-(-5));
    i++;
}
while(i<15);
}
int main()
{
    float tablica[15];
    wczytaj(tablica);
    int i = 0;
    for(int i=0; i<15; i++)
    {
        cout<<tablica[i]<<",";

    }
    cout<<endl<<"Najczesciej wystepuja:"<<tablica[i]<<endl;

    return 0;
}

