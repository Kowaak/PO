#include <iostream>

using namespace std;

int main()
{
    system("color 0a");
    bool a = false;
    float b = 3.14;
    float *wsk;
    wsk=&b;
    cout << b <<" "<< &b <<endl;
    cout << *wsk <<" "<<wsk<< endl;
    *wsk=3;
    cout<<*&*wsk<<" "<<wsk<<endl;
    cout << b <<" "<< &b <<endl;
    char znak = 'x';
    char *wsk2;
    wsk2=&znak;
    cout<<*&*wsk2<<" "<<wsk2<<endl;
    cout << znak <<" "<< &znak <<endl;
    system("pause");
    return 0;
}
