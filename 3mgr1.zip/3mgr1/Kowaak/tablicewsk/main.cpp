#include <iostream>

using namespace std;

void wczytaj(int n,int tab[]){
    for(int i;i<n;i++){
        cin>>tab[i];
    }
}
/*void wypisz(int n,int tab[]){
    cout<<"Warto��i: "<<endl;
    for(int i;i<n;i++){
        cin>>tab[i];
    }
} */
int main()
{
    int n;
    cout<<"Wielko�c tablicy: ";
    cin>>n;
    int tab[n];
    wczytaj(n,tab);
    //wypisz(n,tab);

    //napisz prgram zawierajacy funkcje wczytaj wypisz oraz oblicz
    //w kt�rej odwr�cimy tablice
    return 0;
}
