#include <iostream>
using namespace std;

union status{
    char men[30];

};

struct uczen{
	string imie;
	string nazwisko;
	int id_leg;
    string kier;
    string przed;
    char wyk[50];
    int oce1;
    int oce2;
    int oce3;
	status pol;
};

int main()
{
	uczen Jan;
	cout<<"Podaj plec: "<<endl;
    cin>>Jan.pol.men;
    cout<<"Podaj imie: "<<endl;
    cin>>Jan.imie;
    cout<<"Podaj nazwisko: "<<endl;
    cin>>Jan.nazwisko;
    cout<<"Podaj nr legitymacji: "<<endl;
    cin>>Jan.id_leg;
    cout<<"Podaj stopien wyksztalcenia: "<<endl;
    cin>>Jan.wyk;
    cout<<"Podaj kierunek nauki: "<<endl;
    cin>>Jan.kier;
    cout<<"Podaj swoj ulubiony przedmiot szkolny: "<<endl;
    cin>>Jan.przed;

    cout<<"W skali od 1 do 10 jak bardzo lubisz swoja szkole : "<<endl;
    cin>>Jan.oce1;
    cout<<"W skali od 1 do 10 jak bardzo stresujesz sie w szkole : "<<endl;
    cin>>Jan.oce2;
    cout<<"W skali od 1 do 10 czy polecilbys ta szkole innym: "<<endl;
    cin>>Jan.oce3;

    cout<<"Twoje odpowiedzi: "<<endl;
    cout<<Jan.pol.men<<" "<<Jan.imie<<" "<<Jan.nazwisko<<" "<<Jan.id_leg<<" "<<Jan.wyk<<" "<<Jan.kier<<" "<<Jan.przed<<" "<<Jan.oce1<<" "<<Jan.oce2<<" "<<Jan.oce3<<endl;

	return 0;
}
