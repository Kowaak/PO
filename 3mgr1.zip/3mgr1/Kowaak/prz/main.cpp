#include <iostream>
#include <math.h>
#include <iomanip>
using namespace std;

int main()
{   //wypisz warto�ci sin,cos i tan, zastosuj tabele
    system("color 0a");
    cout<<setw(10);
    cout<<setprecision(7);
    cout<<setfill('*');
    cout<<"a\t30"
    cout<<sin()<<"\t";
    cout<<cos()<<"\t";
    cout<<tan()<<"\t";

    cout<<endl;
    int a;
    cout<<"Podaj dlugosc boku kwadratu: ";
    cin>>a;
    cout<<"Pole wynosi: "<<a*a<<endl;
    int b;
    a = 0;
    cout<<"Podaj dlugosc boku a prostokata: ";
    cin>>a;
    cout<<"Podaj dlugosc boku b prostokata: ";
    cin>>b;
    cout<<"Pole wynosi: "<<a*b<<endl;
    a = 0;
    b = 0;
    cout<<"Podaj dlugosc boku a trojkata: ";
    cin>>a;
    cout<<"Podaj dlugosc boku b trojkata: ";
    cin>>b;
    cout<<"Pole wynosi: "<<(a+b)/2<<endl;
    system("pause");
    return 0;
}
