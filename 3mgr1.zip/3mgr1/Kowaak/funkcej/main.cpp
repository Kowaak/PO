#include <iostream>
#include <math.h>
#include <iomanip>
using namespace std;

int SumaPotega(int n,int k){
    int i, suma = 0;
    for (i=1; i <=n; i++)
        suma += pow(i,k);
    return (suma);
}

void ascii(){
    int p;
    cout<<"Podaj znak: ";
    cin>>p;
    cout<<"Wartosc ascii danego znaku to: "<<char(p);
}
int main()
{
    cout<<SumaPotega(3,2)<<endl;
    ascii();
    return 0;
}
