#include <iostream>
#include <cmath>
using namespace std;
/*
struct bing{
    string *x;
    int *y;
    float *z;
    string xx;
};  */
struct uczen{
    string *imie;
    string *nazwisko;
    string *klasa;
    int *wiek;
    float *wzrost;
};

int main()
{/*
    string a = "Ben";
    int b = 7;
    float c = 2.71;

    bing *wsk = new bing;

    wsk->x = &a;
    wsk->y = &b;
    wsk->z = &c;
    wsk->xx = "Jan";

    cout<<*wsk->x<<endl;
    cout<<*wsk->y<<endl;
    cout<<*wsk->z<<endl;
    cout<<wsk->xx<<endl;

    delete wsk;
    cout<<"-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"<<endl;
    bing bezWsk;
    a = "Mietek";
    bezWsk.x = &a;
    bezWsk.xx = "Maciej";
    cout<<*bezWsk.x<<endl;
    cout<<bezWsk.xx<<endl;  */
    /*
    string imi = "Filip";
    string nazwisk = "Zalecki";
    string klas = "2m";
    int wie = 16;
    float wzr = 180;

    uczen *wsk = new uczen;

    wsk->imie = &imi;
    wsk->nazwisko = &nazwisk;
    wsk->klasa = &klas;
    wsk->wiek = &wie;
    wsk->wzrost = &wzr;

    cout<<*wsk->imie<<endl;
    cout<<*wsk->nazwisko<<endl;
    cout<<*wsk->klasa<<endl;
    cout<<*wsk->wiek<<endl;
    cout<<*wsk->wzrost<<endl; */

    cout<<"sin(30) = "<< sin(30/180*M_PI) <<endl;
 /*   cout<<"sin(45) = "<< sin(45/180*M_PI) <<endl;
    cout<<"sin(60) = "<< sin(60/180*M_PI) <<endl;
    cout<<"sin(90) = "<< sin(90/180*M_PI) <<endl;
    cout<<"sin(180) = "<< sin(180/180*M_PI) <<endl;
    */
    return 0;
}
