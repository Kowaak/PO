#include <iostream>

using namespace std;

int main()
{
  /*  int iStart;
    cin>>iStart;
    while( iStart >= 0 )
    {
        cout << iStart << ", ";
        --iStart;
    }
    cout << "Booom! :)" << endl; */
    //napisz program ktory bedzie zgadywal pomyslana liczbe w przedziale od 1 do 10.
    //zastosuj optymalne rozwiazanie
    cout<<"1 - wieksza"<<endl;
    cout<<"2 - mniejsza"<<endl;
    cout<<"3 - poprawna liczba"<<endl;
    int wy=0,prz=1,krz=10;
    while (wy!=3)
    {


    cout<<wy;
    }
    return 0;
}
