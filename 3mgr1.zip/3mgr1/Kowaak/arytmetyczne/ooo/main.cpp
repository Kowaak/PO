#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    cout<<"Trunc"<<endl;
    cout<<trunc(4.00)<<endl;
    cout<<trunc(3.49)<<endl;
    cout<<trunc(3.50)<<endl;
    cout<<trunc(-3.49)<<endl;
    cout<<trunc(-3.50)<<endl;
    cout<<trunc(-4.00)<<endl;

    cout<<M_PI<<endl;
    cout<<M_E<<endl;
    cout<<endl;

    float r;
    //obwod i pole kola dla r podanego przez uzytkownika
    cout<<"Podaj r: ";
    cin>>r;
    cout<<"Obwod: "<<2*M_PI*r<<endl;
    cout<<"Pole: "<<M_PI*pow(r,2)<<endl;

    //float log(float x);
    //float log10(float x);
    //float log2(float x);

    cout<<log(M_E)<<endl;
    cout<<log10(100)<<endl;
    cout<<log2(16)<<endl;


    cout<<log(25)/log(5)<<endl; //log5(25)

    cout<<fabs(-16.99)<<endl;
    return 0;
}
