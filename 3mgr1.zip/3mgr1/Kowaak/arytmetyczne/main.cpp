#include <iostream>

using namespace std;

int main()
{
    system("color 0a");
    int a,b,c,d,e,f;
    a = 2 + 3;
    b = a + 4;
    c = (b=7) - 3;
    d = a = b = c;
    e = a*b/c+2-1;
    f = b%2;
    float m;
    m = 9.0/2.0;
    m = 9/2.0;
    m = 9.0/2;
    m = 9/2;
    cout << m << endl;
    cout <<5/2<<" "<<(double)5/2<< endl;
    system("pause");
    int z,x,y;
    ++z;
    x--;
    y = ++z+x--;
    y = z + x;
    return 0;
}
