#include<iostream>
using namespace std;
//struktura globalna widoczna w ka�dym zak�tku
struct uczen{
	char Imie[20]; //elementy struktury
	char nazwisko[20];
	char klasa[3];
    int rocznik;
};

int main()
{
    struct adres{
        char miasto[20];
        char ulica[20];
        char nr_domu[5];
    };
    struct ks{
        char tytul[20];
        char autor[20];
        char wydanie[20]
    };
	uczen filip = {"Filip","Zalecki","2m",2007};
    cout<<filip.Imie<<" "<<filip.nazwisko<<" "<<filip.klasa<<" "<<filip.rocznik<<" "<<endl;

    adres nr1 = {"Radomsko","Narutowicza","17A"};
    cout<<nr1.miasto<<" "<<nr1.ulica<<" "<<nr1.nr_domu<<endl;

    ks dz = {"A.Mickiewicz","Pan tadeusz","swdrfgtkl"}

	return 0;
}
