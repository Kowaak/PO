#include <iostream>

using namespace std;

int main()
{
    //1. Urochomienie debuggera
    //2. Otworzenie okienka z danymi
    int a = 3;
    a + 6;
    cout<<a;
    system("pause");
    return 0;
}
