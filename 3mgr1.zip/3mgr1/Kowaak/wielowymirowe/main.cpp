#include <iostream>

using namespace std;

int main()
{
    int t[5][5] = {{1,2,3,4,5},{1,2,3,4,5},{1,2,3,4,5},{1,2,3,4,5},{1,2,3,4,5}};
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            if(i==j){
            t[i][j] = 0;
            cout<<t[i][j]<<"\t";
            }else{
                cout<<t[i][j]<<"\t";
            }
        }
        cout<<endl;
    }
    //wprowadz do tablicy 5 na 5 wartosci i wyswietl tablice z podzialem na wiersze

    //wyzerowa� te elementy tablicy kt�re nie znajduja sie na przekatnej glownej

    return 0;
}
