#include <iostream>
using namespace std;
/*int main()

{
    for( int x = 0; x < 10; x++ )
    {
        if( x == 7 )
        {
            cout << "Teraz 'x' wynosi " << x << "." << endl;
            cout << "Przerywam petle!" << endl;
            break;
        }
        cout << "x = " << x << endl;
    }
    cout << "Teraz jestem tu :)" << endl;
    return 0;
}


{
    for( int x = 0; x < 8; x++ )
    {
        cout << "x = " << x << endl;
        if( x == 2 || x == 3 || x == 5 )
        {
            cout << "Teraz 'x' wynosi " << x;
            cout << " - wywoluje continue!" << endl;
            continue;
        }
        cout << "KONIEC kroku x = " << x << endl;
    }
    return 0;
}
*/
float mnoz(float a,float b)
{
    return(a*b);
}
int main(void)
{
    cout<<mnoz(2.7,3.1)<<endl;
    return 0;
}
