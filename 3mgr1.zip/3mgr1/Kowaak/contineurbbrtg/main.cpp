#include <iostream>

using namespace std;
float silnia(unsigned long s,unsigned long c);
int main(void)
{
  /*  for( int x = 0; x < 10; x++ )
    {
        if( x == 7 )
        {
            cout << "Teraz 'x' wynosi " << x << "." <<endl;
            cout << "Przerywam petle!" <<endl;
            break;
        }
        cout << "x = " << x << endl;
    }
    cout << "Teraz jestem tu :)" << endl;
    for( int x = 0; x < 8; x++ )
    {
        cout << "x = " << x << endl;
        if( x == 2 || x == 3 || x == 5 )
        {
            cout << "Teraz 'x' wynosi " << x;
            cout << " - wywoluje continue!" << endl;
            continue;
        }
        cout << "KONIEC kroku x = " << x << endl;
    }*/
    cout<<silnia(4,6);
    return 0;
}
float silnia (unsigned long s,c)
    {
        if(s<=1)
            return 1;
        else
            return(s*c);
    };
