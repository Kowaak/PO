#include <iostream>

using namespace std;

int main()
{
    /*
    int a,b;
    cout<<"Podaj a: ";
    cin>>a;
    cout<<"Podaj b: ";
    cin>>b;
    while (a != b)
    {
    if (a < b)
    b -= a;
    else
    a -= b;
    }
    cout<<"Wynik: "<<a<<endl;
    return 0; */
    float a,b,i;
    cout<<"Podaj a: ";
    cin>>a;
    cout<<"Podaj b: ";
    cin>>b;
    while (b > 0)
    {
    i=a%b;
    a=b;
    b=i;
    }
    cout<<"Wynik: "<<a<<endl;
}

