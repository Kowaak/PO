#include <iostream>
#include <string>
#include <cctype>

using namespace std;

int main() {
    cout<<"Podaj znak: "<<endl;
	/*char znak;
    scanf( "%c", & znak );
    if( isalnum( znak ) )
     printf( "Wprowadziles cyfre lub litere alfabetu i jest to: %c\n", znak );
    else{
        cout<<"Nie wprowadziles cyfry ani litery "<<endl;
    };

    char znak2;
    scanf( "%c", & znak2 );
    if( isdigit( znak2 ) )
     printf( "Wprowadziles cyfre i jest to: %c\n", znak2 );
    else cout<<"Nie wprowadziels cyfry"<<endl;

    char znak;
    scanf( "%c", & znak );
    if( isalpha( znak ) )
     printf( "Wprowadziles litere alfabetu i jest to: %c\n", znak );
    else cout<<"Nie wprowadziles litery"<<endl;

    char znak;
    scanf( "%c", & znak );
    if( islower( znak ) )
     printf( "Wprowadziles mala litere alfabetu i jest to: %c\n", znak );
     else cout<<"Nie"<<endl;*/

     char znak;
    scanf( "%c", & znak );
    if( isupper( znak ) )
     printf( "Wprowadziles duza litere alfabetu i jest to: %c\n", znak );
      else cout<<"Nie"<<endl;


     // naipsz prgram wyznaczajacy dlugosc tekstu
     // napisz prgram wypisujacy tekst litera pod litera
     //napisz program wyswietlajacy napis w postaci znak spacja znak
     //napisz program zliczajacy wystapienie malej litery a

	return 0;
}
