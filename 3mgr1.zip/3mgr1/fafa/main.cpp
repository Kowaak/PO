#include <iostream>
#include <iomanip>
using namespace std;
class A{
public:
    int start,kon;
    int setn(int a,int b){
        start = a;
        kon = b;
    }
    void displAsc(){
        for (int i = start;i<=kon;i++)
        cout<<"|"<<i;
        cout<<"|"<<endl;
    }
};
class B:public A{
public:
    void displDes(){
        for (int i = kon;i>=start;i--)
        cout<<"|"<<i;
        cout<<"|"<<endl;
    }
};
int main()
{
    A a1;
    B b1;
    a1.setn(5,9);
    a1.displAsc();
    b1.setn(5,9);
    b1.displDes();
    return 0;
}
