#include <iostream>
using namespace std;

class Punkt{
protected:
    float x,y;
public:
    void Displ1(){
    cout<<"x: "<<x<<" y: "<<y<<endl;
    }

};
class Prosto:public Punkt{
public:
    float dx,dy;
    float pole = dx*dy;
    void Displ2(){
    cout<<"dx: "<<dx<<" dy: "<<dy<<endl;
    cout<<"Pole: "<<pole<<endl;
    }
};
class Padlo:public Prosto{
public:
    float dh;
    float pole2 = pole * dh;
    void Displ3(){
    cout<<"dh: "<<dh<<" Pole prostopadloscianu: "<<pole2<<endl;
    }
};
class Ciezar:public Padlo{
public:
    float ro;

};
int main(){
    /*
    Punkt p1;
    p1.x=10;
    p1.y=7;
    p1.Displ1();
    */
    Prosto p2;
    p2.dx = 10;
    p2.dy = 7;
    p2.Displ2();

    Padlo p3;
    p3.dh = 2;
    p3.Displ3();

return 0;
}
s
